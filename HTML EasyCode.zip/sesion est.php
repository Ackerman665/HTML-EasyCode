<!DOCTYPE html>
<html>
<head>
	<title>Iniciar sesion</title>
	<META charset="UTF-8">
    <META http-equiv="X-UA-Compatible" content="IE=edge">
    <META name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
	<link rel="stylesheet" href="css/fontello.css">
	<link rel="stylesheet" type="text/css" href="css/login.css">
    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
</head>
<body>
    <?php
    include_once("principio/header.html");
    ?>
    

    <form action="logest.php" method="post">
    	<h1>Iniciar sesion</h1>
    	<label for="Correoelectronico">Correo electronico
        <input type="email" pattern='^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$' title="Ingrese un email válido"  placeholder="Email" name="correoelectronico" id="correoelectronico">
        </label>
    	<label for="pass">Contraseña<input type="password" name="pass"></label>
    	<input type="submit" value="Ingresar">
    </form>

    <?php
    include_once("principio/footer.php");
    ?>
</body>
</html>