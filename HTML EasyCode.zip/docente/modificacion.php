<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Documento sin t&iacute;tulo</title>
</head>

<body>

<?php 


$oMysql = new mysqli("localhost","root","","hecode");
 // $conexion = pg_connect("host=localhost port=5432 user=nombreUsuario password=passwordUsuario dbname=nomBD", PGSQL_CONNECT_FORCE_NEW);
// $conexion = pg_connect("host=localhost dbname=BASE_DE_DATOS user=USUARIO password=CONTRASEÑA");		

$Query="UPDATE registrarc
					SET id= '".$_POST["idNuevo"]."', 
					nombre= '".$_POST["nombre"]."', 
					apellidopaterno = '".$_POST["apellidopaterno"]."', 
					apellidomaterno = '".$_POST["apellidomaterno"]."',
					date= '".$_POST["date"]."', 
					sexo= '".$_POST["sexo"]."', 
					telefono = '".$_POST["telefono"]."', 
					correoelectronico = '".$_POST["correoelectronico"]."',
					area = '".$_POST["area"]."'
					WHERE id = '".$_POST["idBuscar"]."'";
					
					
			
$Result = $oMysql->query( $Query );  // se lanza la consulta

if($Result!=null)
   	print("Se modifico");

else
  	print("No se pudo modicar");


	 
   ?>

</body>
</html>
