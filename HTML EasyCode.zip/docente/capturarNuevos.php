<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Capturar actualizaci&iacute;ón</title>
<link rel="stylesheet" href="css/inde.css">
    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
</head>

<body>
<?php
    include_once("base/header.php");
?>
<?php
require ("buscar.php");
?>

   <form class="opc" action="modificacion.php" target="" method="POST">
            <input style="display:none;" type=text size=40 name="idBuscar" value="<?php echo $idBuscar;?>">
            <TABLE id="tabla" BORDER="1" ALIGN="CENTER">
                <TR>
                    <TD><strong>Id</strong> </TD>
					<TD><input  type=text size=40 name="idNuevo" value="<?php echo $idBuscar;?>"  readonly onmousedown="return false;"> </TD>
                </TR>
                <TR>
                    <TD><strong>Nombre</strong> </TD>
					<TD><input  type=text size=40 name="nombre" value="<?php echo $nombre;?>"> </TD>
                </TR>
               
                <TR>
                    <TD><strong>Apellido paterno</strong> </TD>
                    <td><input type=text size=40 name="apellidopaterno" value="<?php echo $apellidopaterno;?>"></td>
                </TR>
                <TR>
                    <TD><strong>Apellido materno</strong> </TD>
                    <td><input type=text size=40 name="apellidomaterno" value="<?php echo $apellidomaterno;?>"></td>
                </TR>
                <TR>
                    <TD><strong>Fecha de nacimiento</strong> </TD>
                    <td><input type="date" size=40 name="date" value="<?php echo $date;?>" min="1950-01-01" max="2005-12-31"></td>
                </TR>
                <TR>
                    <TD><strong>Sexo</strong> </TD>
					<TD><input type="radio" size=40 name="sexo" value="<?php echo $sexo;?>">Hombre
                    <input type="radio" size=40 name="sexo" value="<?php echo $sexo;?>">Mujer</TD>
                </TR>
                
                <TR>
                    <TD><strong>Teléfono</strong> </TD>
                    <td><input type=text size=40 name="telefono" value="<?php echo $telefono;?>"></td>
                </TR>
                <TR>
                    <TD><strong>Email</strong> </TD>
                    <td><input type=text size=40 name="correoelectronico" value="<?php echo $correoelectronico;?>"></td>
                </TR>
                <TR>
                    <TD><strong>area</strong> </TD>
                    <td><input type=text size=40 name="area" value="<?php echo $area;?>"></td>
                </TR>
                
                
            </TABLE>
            <BR>
                <BR>
            <center> <input type=submit value="Modificar registro" ></center>
            
            
        </form>


        <?php
   include_once("base/footer.html");
    ?>
</body>
</html>
