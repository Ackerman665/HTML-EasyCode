<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>insertar</title>
<link rel="stylesheet" type="text/css" href="css/estilo.css">
<link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
</head>

<body>
    <?php
    include_once("base/header.php");
    ?>

   <form class="opc" action="agregar.php" target="" method="POST">
   <h1>¡Regístrate al curso!</h1>
         <label for="id">Id<input type="text" name="id" id="id" placeholder="No obligatorio"></label>
    	<label for="nombre">Nombre(s)<input type="text" name="nombre" id="nombre" onkeypress="return soloLetras(event);"></label>
		<label for="apellidopaterno">Apellido Paterno<input type="text" name="apellidopaterno" id="apellidopaterno"></label>
		<label for="apellidomaterno">Apellido Materno<input type="text" name="apellidomaterno" id="apellidomaterno"></label>
		<label class="form-date__label" for="input-date">Fecha de nacimiento</label><input class="form-date__input" type="date" 
		id="input-date" name="date" value="2018–07–22" min="1950-01-01" max="2005-12-31"></div>

        <label for="sexo">Sexo<br>
        <input type="radio"id="sexo" name="sexo" value="hombre">Hombre
        <input type="radio" id="sexo" name="sexo" value="mujer">Mujer</label>
        
        <br><br>
		<label for="telefono">Teléfono<input type="text" name="telefono" id="telefono"></label>
		<label for="correoelectronico">Correo electronico
        <input type="email" pattern='^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$' title="Ingrese un email válido"  placeholder="Email" name="correoelectronico" id="correoelectronico">
        </label>


  
        <label for="nivel_curso">Nivel a cursar
                        <select name="area" value="-Any-">
                            <option>- Selecciona un curso -</option>
                            <option value="ba">Básico</option>
                            <option value="in">Intermedio</option>
                            <option value="av">Avanzado</option>
                        </select>
        </label>
        <br> <br>  
            <BR>
                <BR>
            <center> <input type=submit value="Agregar" ></center>
            
            
        </form>

        <?php
   include_once("base/footer.html");
    ?>

</body>
</html>
