<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Actualizar</title>
<link rel="stylesheet" href="css/inde.css">
    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
</head>

<body>
<?php
    include_once("base/header.php");
    ?>

<div class="opc">
<?php 

$mysql = new mysqli("localhost","root","","hecode");

$Query = "select * from registrarc";
$Result = $mysql->query( $Query );


	 $numeroRegistros=$Result->num_rows;   
	 if($numeroRegistros<=0) 
   { 
     echo "<div align='center'>"; 
     echo "<h2>No se encontraron registros</h2>"; 
     echo "</div><hr> "; 
   }else{
   ?>
       <table border=1>
        <tr>
		<td><strong> Id</strong></td>
		<td><strong> Nombre</strong></td>
		<td><strong> Apellido paterno</strong></td>
		<td><strong> apellidomaterno</strong></td>
		<td><strong> Fecha de nacimiento</strong></td>
		<td><strong> Sexo</strong></td>
		<td><strong> Teléfono</strong></td>
		<td><strong> Email</strong></td>
		<td><strong> Área</strong></td>
		</tr>
		<?php
        while($row =$Result->fetch_array()) {	  
		$id=$row["id"];
           ?>
		   <tr>
		   <td> <a href="capturarNuevos.php ? id=<?php print($id); ?>"> <?php print($id); ?> </a>  </td>
		   <td> <?php printf($row["nombre"]); ?>   </td>
		   <td> <?php printf($row["apellidopaterno"]); ?>   </td>
		   <td> <?php printf($row["apellidomaterno"]); ?>   </td>
		   <td> <?php printf($row["date"]); ?>   </td>
		   <td> <?php printf($row["sexo"]); ?>   </td>
		   <td> <?php printf($row["telefono"]); ?>   </td>
		   <td> <?php printf($row["correoelectronico"]); ?>   </td>
		   <td> <?php printf($row["area"]); ?>   </td>
           </tr>
<?php	}
}
?>
</table>

</div>
<?php
   include_once("base/footer.html");
    ?>
</body>
</html>
