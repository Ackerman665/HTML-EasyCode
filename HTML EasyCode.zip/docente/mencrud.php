<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Estudiantes inscritos</title>
<link rel="stylesheet" href="css/inde.css">
    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
</head>

<body>
    <?php
    include_once("base/header.php");
    ?>
    <br><br><br><br>
    <section class="title">
		<h1>LISTA DE USUARIOS</h1>
	</section>

	<nav class="navegacion">
		<ul class="menu">

			<li class="first-item">
				<a href="insertar.php">
					<img src="img/insertar.jpeg" class="imagen">
					<span class="text-item">INSERTAR</span>
					<span class="down-item"></span>
				</a>
			</li>
            
			<li>
				<a href="eliminar.php">
					<img src="img/borrar.jpeg" class="imagen">
					<span class="text-item">ELIMINAR</span>
					<span class="down-item"></span>
				</a>
			</li>

			<li>
				<a href="mostrar.php">
					<img src="img/ver.jpeg" class="imagen">
					<span class="text-item">VISUALIZAR</span>
					<span class="down-item"></span>
				</a>
			</li>

			<li>
				<a href="actualizar.php">
					<img src="img/modificar.jpeg"class="imagen">
					<span class="text-item">ACTUALIZAR</span>
					<span class="down-item"></span>
				</a>
			</li>

		</ul>
	</nav>
	
    <br><br><br><br><br><br><br>
    <?php
   include_once("base/footer.html");
    ?>
</body>
</html>
