<?php 
//Busca registro  a través del nombre elegido
$idBuscar=$_GET["id"];
$oMysql = new mysqli("localhost","root","","hecode");
$Query="select * from registrarc WHERE id = '".$idBuscar."'";
$Result = $oMysql->query( $Query );

if($Result==null)
   	print("No se  encuentra el registro");
else{
      $row =$Result->fetch_array();
  	  $nombre=$row["nombre"];
	  $apellidopaterno=$row["apellidopaterno"];
	  $apellidomaterno=$row["apellidomaterno"];
	  $date=$row["date"];
	  $sexo=$row["sexo"];
	  $telefono=$row["telefono"];
	  $correoelectronico=$row["correoelectronico"];
	  $area=$row["area"];
	}
?>
