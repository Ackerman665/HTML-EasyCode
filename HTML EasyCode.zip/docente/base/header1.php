<!DOCTYPE html>
<html lang="es">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML EasyCode</title>

    <link rel="stylesheet" href="css/fontello.css">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/menu.css">

</head>

<body>
    
    <header>
        <div class="conten">
            <h1 class="reg"><img href="" src="img/HTML_EASYCODE.png"></h1>
            <h1 class="reg">HTML EasyCode</h1>
            <input type="checkbox" id="menu-bar">
            <label class="icon-menu" for="menu-bar"></label>
             
                
            <?php $url="http://".$_SERVER['HTTP_HOST']."/easycode"?>
         
            <nav class="menu">
                <a href="<?php echo $url?>/docente/cuenta.php">Cuenta</a>
                <a href="mostrar_estudiantes.php">Progreso</a>
                <a href="mostrar_materias.php">Materias</a>
            </nav>

                
    </header>
</body>

</html>