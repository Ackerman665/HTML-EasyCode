<?php

$host = "localhost";
$usuario = "root";
$clave = "";
$db = "hecode";

$con = mysqli_connect($host, $usuario, $clave, $db); 

if (!$con) {
    die ("No hay conexion:".mysqli_connect_error()); 
}

$correo = $_POST["correoelectronico"];
$contra = $_POST["pass"];


$query = mysqli_query($con, "SELECT * from docente WHERE correoelectronico = '".$correo."' and pass = '".$contra."' ");
$nr = mysqli_num_rows($query);

session_start();
if ($nr == 1) {
    header('Location:docente/cuenta.php');

} else if ($nr == 0){
    echo "Datos erroneos: si no se encuentra registrado debe hacerlo primero";    
}

?>