<!DOCTYPE html>
<html>
<head>
	<title>Registrarse</title>
	<META charset="UTF-8">
    <META http-equiv="X-UA-Compatible" content="IE=edge">
    <META name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
	<link rel="stylesheet" href="css/fontello.css">
	<link rel="stylesheet" type="text/css" href="css/registro.css">
    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
</head>
<body>
    <?php
     include_once("principio/header.html");
    ?> 

    <form method="post">
    	<h1>¡Registrarse!</h1>
    	<label for="nombre">Nombre(s)<input type="text" name="nombre" id="nombre"></label>
		<label for="apellidopaterno">Apellido Paterno<input type="text" name="apellidopaterno" id="apellidopaterno"></label>
		<label for="apellidomaterno">Apellido Materno<input type="text" name="apellidomaterno" id="apellidomaterno"></label>
		<label class="form-date__label" for="input-date">Fecha de nacimiento</label><input class="form-date__input" type="date" 
		id="input-date" name="date" value="2018–07–22" min="1950-01-01" max="2005-12-31"></div>

        <label for="sexo">Sexo
        <br>
        <input type="radio" name="sexo" value="hombre">Hombre
        <input type="radio" name="sexo" value="mujer">Mujer</label>
        
        <br><br>
		<label for="telefono">Teléfono<input type="text" name="telefono" id="telefono"></label>
		<label for="correoelectronico">Correo electronico
        <input type="email" pattern='^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$' title="Ingrese un email válido"  placeholder="Email" name="correoelectronico" id="correoelectronico">
        </label>
		<label for="pass">Contraseña<input type="password" name="pass" id="pass"></label>
    	<input type="submit" name="Registrarse">

    </form>

        <?php 
        include("registrar.php");
        include_once("principio/footer.html");
        ?>


</body>
</html>