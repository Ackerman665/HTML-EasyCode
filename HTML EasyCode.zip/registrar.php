<?php 

$conex = mysqli_connect("localhost","root","","hecode"); 

if (isset($_POST['Registrarse'])) {
    if (strlen($_POST['nombre']) >= 1 && 
	    strlen($_POST['apellidopaterno']) >= 1 && 
		strlen($_POST['apellidomaterno']) >= 1 && 
		strlen($_POST['date']) >= 1 && 
		strlen($_POST['sexo']) >= 1 && 
		strlen($_POST['telefono']) >= 1 && 
		strlen($_POST['correoelectronico']) >= 1 && 
		strlen($_POST['pass']) >= 1){

	    $nombre = trim($_POST['nombre']);
	    $apellidopaterno = trim($_POST['apellidopaterno']);
		$apellidomaterno = trim($_POST['apellidomaterno']);
		$date = trim($_POST['date']);
		$sexo = trim($_POST['sexo']);
		$telefono = trim($_POST['telefono']);
		$correoelectronico = trim($_POST['correoelectronico']);
		$pass = trim($_POST['pass']);
	    $consulta = "INSERT INTO alumnos (nombre, apellidopaterno, apellidomaterno, date, sexo, telefono, correoelectronico, pass) VALUES ('$nombre','$apellidopaterno','$apellidomaterno','$date','$sexo','$telefono','$correoelectronico','$pass')";
		
	    $resultado = mysqli_query($conex,$consulta);
	    if ($resultado) {
	    	?> 
	    	<h3 class="ok">¡Te has inscrito correctamente!</h3>
           <?php
	    } else {
	    	?> 
	    	<h3 class="bad">¡Ups ha ocurrido un error!</h3>
           <?php
	    }
    }   else {
	    	?> 
	    	<h3 class="bad">¡Por favor complete los campos!</h3>
           <?php
    }
}

?>