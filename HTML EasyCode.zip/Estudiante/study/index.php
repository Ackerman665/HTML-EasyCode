<?php
?>
<?php
# Simplemente redireccionamos al listado de alumnos
header("Location: mostrar_estudiantes.php");