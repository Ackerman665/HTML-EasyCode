<?php
?>
<?php
include_once "conexion.php";
include_once "encabezado.php";
include_once "Materia.php";
$materias = Materia::obtener();
?>
<div class="row">
    <div class="col-12">
        <h1>Listado de materias</h1>
      
    </div>
    <div class="col-12 table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nombre</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php foreach ($materias as $materia) { ?>
                    <tr>
                        <td><?php echo $materia["nombre"] ?></td>
                       
                            
                       
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<?php
include_once "pie.php";
