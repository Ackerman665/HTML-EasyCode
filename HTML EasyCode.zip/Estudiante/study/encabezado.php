
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
    <link rel="stylesheet" href="css/estilo.css">

    <style>
        body {
            padding-top: 70px;
        }
    </style>
    <title>Control de notas</title>
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-dark bg-success fixed-top">
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="mostrar_estudiantes.php">Estudiantes</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="mostrar_materias.php">Materias</a>
                </li>
            </ul>
        </div>
        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav ml-auto">
                
            </ul>
        </div>
    </nav>
    <main class="container-fluid">