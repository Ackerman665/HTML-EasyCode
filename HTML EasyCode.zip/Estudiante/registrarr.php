<!DOCTYPE html>
<html>
<head>
	<title>Datos del Pago</title>
	<META charset="UTF-8">
    <META http-equiv="X-UA-Compatible" content="IE=edge">
    <META name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
	<link rel="stylesheet" href="css/fontello.css">
	<link rel="stylesheet" type="text/css" href="css/estilo.css" media="screen" title="no title">
	<body>
	<?php
     include_once("principio/header.php");
    ?> 
	<br><br><br><br><br><br><br><br><br><br>
<FORM>
<?php 

$conex = mysqli_connect("localhost","root","","hecode"); 

if (isset($_POST['Enviar'])) {
    if (strlen($_POST['nombre']) >= 1 && 
	    strlen($_POST['apellidopaterno']) >= 1 && 
		strlen($_POST['apellidomaterno']) >= 1 && 
		strlen($_POST['date']) >= 1 && 
		strlen($_POST['sexo']) >= 1 && 
		strlen($_POST['telefono']) >= 1 && 
		strlen($_POST['correoelectronico']) >= 1 && 
		strlen($_POST['area']) >= 1 && 
		strlen($_POST['pago']) >= 1){

	    $nombre = trim($_POST['nombre']);
	    $apellidopaterno = trim($_POST['apellidopaterno']);
		$apellidomaterno = trim($_POST['apellidomaterno']);
		$date = trim($_POST['date']);
		$sexo = trim($_POST['sexo']);
		$telefono = trim($_POST['telefono']);
		$correoelectronico = trim($_POST['correoelectronico']);
		$area = trim($_POST['area']);
		$pago = trim($_POST['pago']);
	    $consulta = "INSERT INTO registrarc (nombre, apellidopaterno, apellidomaterno, date, sexo, telefono, correoelectronico, area) VALUES ('$nombre','$apellidopaterno','$apellidomaterno','$date','$sexo','$telefono','$correoelectronico','$area')";

        if(isset($_POST['area'])){
			$area = $_POST['area'];
			echo "<h3>Su curso seleccionado es:</h3>";
			switch ($area) {
			  case 'ba':
				   echo "HTML 1";
				   break;
			  case 'in':
				   echo "HTML 2";
				   break;
			  case 'av':
				   echo "HTML 3";
				   break;
			  default:
				   echo "Por favor elige un curso";
				   break;
			}  }
   
			if(isset($_POST['pago'])){
			   $pago = $_POST['pago'];
			   echo "<h3>Su pago seleccionado es:</h3>";
			   switch ($pago) {
				 case 'tra':
					  echo "La cuenta a transferir es ......";
					  break;
				 case 'dep':
					  echo "La cuenta para el depósito es";
					  break;
				 default:
					  echo "Por favor elige un método de pago";
					  break;
			   }
		   }

	    $resultado = mysqli_query($conex,$consulta);
	    if ($resultado) {
	    	?> 
	    	<h3 class="ok">¡Te has inscrito correctamente!</h3>
           <?php
	    } else {
	    	?> 
	    	<h3 class="bad">¡Ups ha ocurrido un error!</h3>
           <?php
	    }
	}     else {
	    	?> 
	    	<h3 class="bad">¡Por favor complete los campos!</h3>
           <?php
    }
}


?>
</FORM>
	<br><br><br><br><br><br><br><br>

	<?php 
        include_once("principio/footer.html");
        ?>
</body>
</html>