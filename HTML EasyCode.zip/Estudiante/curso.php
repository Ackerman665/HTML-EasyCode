<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Registrate</title>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/fontello.css">
  </head>
  <body>

  <?php
     include_once("principio/header.php");

    ?>
  
</header>

    <img src="img/fondoc.jpg" width="1350">
    <br>
    <br>
    <br>
    <main class="seccion contenedor">
    <h2>Inscribete a un curso</h2>
        <div class="contenedor-anuncios">      
            <div class="anuncio">
                <img src="img/html.png" alt="">
                <div class="contenido.anuncio">
                    <h3>HTML 1</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 5</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 10</p>    
                        </li>
                    </ul>
                    
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>
            <div class="anuncio">
                <img src="img/html.png" alt="">
                <div class="contenido.anuncio">
                    <h3>HTML 2</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 5</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 10</p>    
                        </li>
                    </ul>
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>
            <div class="anuncio">
                <img src="img/html.png" alt="">
                <div class="contenido.anuncio">
                    <h3>HTML 3</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 5</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 10</p>    
                        </li>
                    </ul>
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>   
            <div class="anuncio">
                <img src="img/css.png" alt="">
                <div class="contenido.anuncio">
                    <h3>CSS 4</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 2</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 20</p>    
                        </li>
                    </ul>
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>
            <div class="anuncio">
                <img src="img/css.png" alt="">
                <div class="contenido.anuncio">
                    <h3>CSS 5</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 2</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 20</p>    
                        </li>
                    </ul>
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>
            <div class="anuncio">
                <img src="img/css.png" alt="">
                <div class="contenido.anuncio">
                    <h3>CSS 6</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 2</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 20</p>    
                        </li>
                    </ul>
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>
            <div class="anuncio">
               <img src="img/JS.png" alt="">
                <div class="contenido.anuncio">
                    <h3>JAVASCRIPT 7</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 2</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 20</p>    
                        </li>
                    </ul>
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>
            <div class="anuncio">
                <img src="img/JS.png" alt="">
                <div class="contenido.anuncio">
                    <h3>JAVASCRIPT 8</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 2</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 20</p>    
                        </li>
                    </ul>
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>
            <div class="anuncio">
                <img src="img/JS.png" alt="">
                <div class="contenido.anuncio">
                    <h3>JAVASCRIPT 9</h3>
                    <p>En este curso podras ver los siguientes temas:</p>
                    <p class="precio">$1,000</p>
                    <ul class="iconos-caracteristicas">
                        <li>
                            <img src="img/modulo.svg" width="20px">
                            <p>Modulo: 2</p>    
                        </li>
                        <li>
                            <img src="img/hora.svg" width="20px">
                            <p>Horas: 20</p>    
                        </li>
                    </ul>
                    <a href="registro.php" class="boton boton-amarillo d-block">Registrarse</a>
                </div>
            </div>

        </div>
        <div class="ver-todas">
            <a href="anuncios.html" class="boton boton-verde">Ver todos los cursos</a>
        </div>
    </main>
    <?php
  include_once("principio/footer.html");
    ?>
    </body>
</html>