<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML EasyCode</title>

    <link rel="stylesheet" href="css/fontello.css">
    <link rel="stylesheet" href="css/estilosE.css">
</head>

<body>
    <header>
        <div class="conten">
            <h1 class="reg"><img href="" src="img/HTML_EASYCODE.png"></h1>
            <h1 class="reg">HTML EasyCode</h1>
            <input type="checkbox" id="menu-bar">
            <label class="icon-menu" for="menu-bar"></label>
            <?php $url="http://".$_SERVER['HTTP_HOST']."/easycode"?>
            <nav class="menu">
                <a href="#">Mi cuenta</a>
                <a href="<?php echo $url?>/Estudiante/curso.php">Cursos</a>
                <a href="<?php echo $url?>/Estudiante/eventos.php">Calendario</a>
                <a href="<?php echo $url?>/Estudiante/study/mostrar_estudiantes.php">Progresos</a>
            </nav>

        </div>
    </header>
</body>

</html>