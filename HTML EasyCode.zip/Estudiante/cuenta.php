<?php

$link = mysqli_connect("localhost","root",""); 

mysqli_select_db($link,"hecode");

$tildes = $link->query("SET NAMES 'utf8'"); //Para que se muestren las tildes

$result = mysqli_query($link, "SELECT * FROM alumnos ORDER BY nombre DESC LIMIT 1");

mysqli_data_seek ($result, 9999);

$extraido= mysqli_fetch_array($result);

mysqli_free_result($result);

mysqli_close($link);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
    <LINK REL=StyleSheet HREF="css/cuentaE.css" TYPE="text/css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">

    <title>Mi cuenta</title>
</head>
<body>
    <?php
    
   include_once("principio/header.php");
    //include_once("principio/aside.html");
    ?>
    
  <div class="cont">
  
    <h1>Perfil del Alumno</h1>
    <div><img class="img-perfil" src="img/sombrero.png"/></div>
    <h2><?php echo $extraido['nombre'] ?> <?php echo $extraido['apellidopaterno'] ?> <?php echo $extraido['apellidomaterno'] ?></h2>
</div>
<hr width=400>
    <div class="cont1">
      <h1 class="titu">Datos del estudiante</h1>
      <p>Nombre: <?php echo $extraido['nombre'] ?></p>
      <p>Apellido Paterno: <?php echo $extraido['apellidopaterno'] ?></p>
      <p>Apellido Materno: <?php echo $extraido['apellidomaterno'] ?></p>
      <p>Fecha de nacimiento: <?php echo $extraido['date'] ?></p>
      <p>Sexo: <?php echo $extraido['sexo'] ?></p>
      <p>Telefono: <?php echo $extraido['telefono'] ?></p>
      <p>Correo: <?php echo $extraido['correoelectronico'] ?></p>
      <p>Contraseña: <?php echo $extraido['pass'] ?></p>
    </div>


    <hr width=400>
    <div class="cont">
      <h2 class="titu">Acerca de</h2>

        <a href="#work">Ayuda</a>
        <a href="#about">Privacidad</a>
        <a href="#careers">Terminos de servicio</a>
        <a href="#contact">Sugerencias</a>
        
    </div>
    
    <?php
   include_once("principio/footer.html");
    ?>




</body>
</html>