-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-05-2022 a las 20:09:16
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hecode`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `id` int(9) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `apellidopaterno` varchar(50) NOT NULL,
  `apellidomaterno` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `sexo` varchar(15) NOT NULL,
  `telefono` int(25) NOT NULL,
  `correoelectronico` varchar(70) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`id`, `nombre`, `apellidopaterno`, `apellidomaterno`, `date`, `sexo`, `telefono`, `correoelectronico`, `pass`) VALUES
(1, 'Mafer', 'Diaz', 'Pablo', '2001-06-13', 'mujer', 2147483647, 'Maferdiaz@gmail.com', 'Mafer1234');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes`
--
CREATE TABLE `docente` (
  `id` int(9) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `apellidopaterno` varchar(50) NOT NULL,
  `apellidomaterno` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `sexo` varchar(15) NOT NULL,
  `telefono` int(25) NOT NULL,
  `correoelectronico` varchar(70) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `docente`
--

INSERT INTO `docente` (`id`, `nombre`, `apellidopaterno`, `apellidomaterno`, `date`, `sexo`, `telefono`, `correoelectronico`, `pass`) VALUES
(1, 'Carlos', 'Torres', 'Ixmatlahua', '2001-09-04', 'Masculino', 2147483647, 'carlos@gmail.com', 'Carlos');


CREATE TABLE `estudiantes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `grupo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estudiantes`
--

INSERT INTO `estudiantes` (`id`, `nombre`, `grupo`) VALUES
(1, 'Luis Garcia', '1'),
(3, 'Mafer D', '4');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventoscalendar`
--

CREATE TABLE `eventoscalendar` (
  `id` int(11) NOT NULL,
  `evento` varchar(250) NOT NULL,
  `color_evento` varchar(20) NOT NULL,
  `fecha_inicio` varchar(20) NOT NULL,
  `fecha_fin` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materias`
--

CREATE TABLE `materias` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `materias`
--

INSERT INTO `materias` (`id`, `nombre`) VALUES
(1, 'HTML 1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas_estudiantes_materias`
--

CREATE TABLE `notas_estudiantes_materias` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_estudiante` bigint(20) UNSIGNED NOT NULL,
  `id_materia` bigint(20) UNSIGNED NOT NULL,
  `puntaje` decimal(9,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `notas_estudiantes_materias`
--

INSERT INTO `notas_estudiantes_materias` (`id`, `id_estudiante`, `id_materia`, `puntaje`) VALUES
(1, 3, 1, '10.00'),
(2, 1, 1, '10.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registrarc`
--

CREATE TABLE `registrarc` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellidopaterno` varchar(30) NOT NULL,
  `apellidomaterno` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `sexo` varchar(15) NOT NULL,
  `telefono` int(30) DEFAULT NULL,
  `correoelectronico` varchar(30) NOT NULL,
  `area` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correoelectronico` (`correoelectronico`);

--
-- Indices de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `eventoscalendar`
--
ALTER TABLE `eventoscalendar`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `materias`
--
ALTER TABLE `materias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notas_estudiantes_materias`
--
ALTER TABLE `notas_estudiantes_materias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_estudiante` (`id_estudiante`),
  ADD KEY `id_materia` (`id_materia`);

--
-- Indices de la tabla `registrarc`
--
ALTER TABLE `registrarc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correoelectronico` (`correoelectronico`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `eventoscalendar`
--
ALTER TABLE `eventoscalendar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `materias`
--
ALTER TABLE `materias`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `notas_estudiantes_materias`
--
ALTER TABLE `notas_estudiantes_materias`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `notas_estudiantes_materias`
--
ALTER TABLE `notas_estudiantes_materias`
  ADD CONSTRAINT `notas_estudiantes_materias_ibfk_1` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_estudiantes_materias_ibfk_2` FOREIGN KEY (`id_materia`) REFERENCES `materias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `registrarc`
--
ALTER TABLE `registrarc`
  ADD CONSTRAINT `registrarc_ibfk_1` FOREIGN KEY (`correoelectronico`) REFERENCES `docente` (`correoelectronico`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
