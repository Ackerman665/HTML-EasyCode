<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML EasyCode</title>
    <link rel="shortcut icon" href="img/HTML_EASYCODE.png" type="image/x-icon">
    <link rel="stylesheet" href="css/estilo.css">
</head>

<body>
    <?php
    include_once("principio/header.html");
    include_once("principio/aside.html");
    ?>
    
    <main>
        <section class="contenedor sobre-nosotros">
            <h2 class="titulo">Sobre nosotros</h2>
            <div class="contenedor-sobre-nosotros">
                <img src="img/equipo.png" alt="" class="imagen-about-us">
                <div class="contenido-textos">
                    <h3><span>1</span>El equipo</h3>
                    <p>Somos un equipo completamente distribuido de 5 personas,
                    estamos trabajando para dar los mejores cursos y así, ayudar a nuestros clientes a desarrollar sus propios proyectos</p>
                    <h3><span>2</span>La plataforma</h3>
                    <p>HTML EasyCode está construido para las personas que desean aprender.
                        Explorará información lógica y convertirá esos conocimientos en acción a través de 
                        integraciones con las principales herramientas de desarrollo Web.</p>
                </div>
            </div>
        </section>
        <section class="portafolio">
            <div class="contenedor">
                <h2 class="titulo">Portafolio</h2>
                <div class="galeria-port">
                    <div class="imagen-port">
                        <img href="https://ackerman665.github.io/LineaDelTiempoEquipo" src="img/img1.png" alt="">
                        <div class="hover-galeria">
                            <img src="img/icon.png" alt="">
                            <p>Línea del tiempo</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="img/img2.png" alt="">
                        <div class="hover-galeria">
                            <img href="https://ackerman665.github.io/PaisesCSS/" src="img/icon.png" alt="">
                            <p>Descripción de paises</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="img/img3.png" alt="">
                        <div class="hover-galeria">
                            <img href="https://ackerman665.github.io/MejoresDramas/" src="img/icon.png" alt="">
                            <p>Mejores Dramas</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="img/img4.png" alt="">
                        <div class="hover-galeria">
                            <img href="https://maferdiaz13.github.io/Fitness/" src="img/icon.png" alt="">
                            <p>Nuestro trabajo</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="img/img5.png" alt="">
                        <div class="hover-galeria">
                            <img href="https://virginiaph.github.io/TematicaPro/" src="img/icon.png" alt="">
                            <p>Imperio</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="img/img6.png" alt="">
                        <div class="hover-galeria">
                            <img href="https://israelmontiel.github.io/PaginaWebIsraeldeJesus/" src="img/icon.png" alt="">
                            <p>Música</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="img/img7.png" alt="">
                        <div class="hover-galeria">
                            <img href="https://carlostorres03.github.io/Misubmenu/dise%C3%B1oresponsive/index.html" src="img/icon.png" alt="">
                            <p>Libros favoritos</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="img/img8.png" alt="">
                        <div class="hover-galeria">
                            <img href="https://ackerman665.github.io/Calculadora/" src="img/icon.png" alt="">
                            <p>Calculadora</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="clientes contenedor">
            <h2 class="titulo">Opiniones de nuestros clientes</h2>
            <div class="cards">
                <div class="card">
                    <img src="img/face1.png" alt="">
                    <div class="contenido-texto-card">
                        <h4>Naim Garcia</h4>
                        <p>Al principio no sabia nada, pero salí con muchos conocimientos nuevos!</p>
                    </div>
                </div>
                <div class="card">
                    <img src="img/face2.png" alt="">
                    <div class="contenido-texto-card">
                        <h4>Ingrid Dionet</h4>
                        <p>Excelentes cursos, sus explicaciones hacen los temas más fáciles!</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="about-services">
            <div class="contenedor">
                <h2 class="titulo">Algunos de nuestros cursos</h2>
                <div class="servicio-cont">
                    <div class="servicio-ind">
                        <img src="img/html.png" alt="">
                        <h3>HTML</h3>
                        <p>HTML es el lenguaje de marcado estándar para las páginas web. Con HTML puedes crear tu propio sitio web. HTML es fácil de aprender. ¡Lo disfrutarás!</p>
                    </div>
                    <div class="servicio-ind">
                        <img src="img/css.png" alt="">
                        <h3>CSS</h3>
                        <p>CSS es el lenguaje que usamos para diseñar un documento HTML. <BR>CSS describe cómo deben mostrarse los elementos HTML.</p>
                    </div>
                    <div class="servicio-ind">
                        <img src="img/js.png" alt="">
                        <h3>JAVA SCRIPT</h3>
                        <p>JavaScript es el lenguaje de programación más popular del mundo, siendo el lenguaje de programación de la Web. JavaScript es fácil de aprender.  <BR>Este curso le enseñará JavaScript desde básico hasta avanzado.</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php
   include_once("principio/footer.html");
    ?>
</body>

</html>